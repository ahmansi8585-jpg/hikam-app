package com.hikam.app;
import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private SpeechRecognizer rec;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "AndroidMic");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
    }

    class Bridge {
        @JavascriptInterface public void startListening(){
            runOnUiThread(new Runnable(){ public void run(){
                if (rec != null) rec.destroy();
                if (!SpeechRecognizer.isRecognitionAvailable(MainActivity.this)) return;
                rec = SpeechRecognizer.createSpeechRecognizer(MainActivity.this);
                rec.setRecognitionListener(new RecognitionListener(){
                    public void onReadyForSpeech(android.os.Bundle p){ js("onNativeState(1)"); }
                    public void onBeginningOfSpeech(){}
                    public void onRmsChanged(float r){}
                    public void onBufferReceived(byte[] buf){}
                    public void onEndOfSpeech(){}
                    public void onError(int e){ js("onNativeState(2)"); }
                    public void onResults(android.os.Bundle r){
                        ArrayList<String> m = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        String s = (m != null && m.size() > 0) ? m.get(0) : "";
                        js("onNativeResult(" + org.json.JSONObject.quote(s) + ")");
                    }
                    public void onPartialResults(android.os.Bundle p){}
                    public void onEvent(int t, android.os.Bundle p){}
                });
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA");
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-SA");
                i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
                i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
                rec.startListening(i);
            }});
        }
    }
    private void js(final String code){ runOnUiThread(new Runnable(){ public void run(){
        if (web != null) web.evaluateJavascript(code, null); }}); }
    @Override protected void onDestroy(){ if (rec != null) rec.destroy(); super.onDestroy(); }
}