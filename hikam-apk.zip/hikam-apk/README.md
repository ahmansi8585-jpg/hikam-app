# تطبيق حِكَم — نشر وبناء APK عبر GitHub

## خطوات النشر (5 دقائق)

### 1) أنشئ مستودعًا جديدًا على GitHub
- ادخل github.com ← New Repository ← سمِّه `hikam-app` (عام Public)
- لا تضف README (سنرفع ملفاتنا)

### 2) ارفع الملفات
من مجلد المشروع على جهازك نفّذ:
```bash
git init
git add .
git commit -m "تطبيق حِكَم الأول"
git branch -M main
git remote add origin https://github.com/USERNAME/hikam-app.git
git push -u origin main
```

### 3) شغّل البناء
- ادخل تبويب **Actions** في المستودع ← اضغط **Run workflow**
- انتظر ~3 دقائق حتى تكتمل العملية بالأخضر ✅

### 4) حمّل ملف APK
- ادخل تبويب **Actions** ← اضغط على آخر عملية ناجحة
- في قسم **Artifacts** اضغط `hikam-app-apk` لتحميل ملف مضغوط يحتوي `hikam-app.apk`

### 5) ثبّت على هاتفك
- انسخ الملف للهاتف ← افتحه ← سيطلب "تثبيت من مصادر غير معروفة" ← اسمح وثبّت
- افتح التطبيق 🎤 واسمح بالميكروفون وانطق أي مثل

## إنشاء إصدار رسمي (Release)
```bash
git tag v1.0 && git push origin v1.0
```
سيُنشأ Release تلقائيًا يحتوي APK جاهزًا للتحميل المباشر.

## هيكل المشروع
| المسار | الوظيفة |
|---|---|
| `AndroidManifest.xml` | تعريف التطبيق وصلاحيات الميكروفون |
| `src/com/hikam/app/MainActivity.java` | واجهة التطبيق + محرك النطق العربي |
| `assets/index.html` | واجهة التطبيق والقصص (25 مثلًا) |
| `.github/workflows/android-build.yml` | البناء التلقائي لملف APK |
